rm cadet*.o
make
